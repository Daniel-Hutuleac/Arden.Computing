## Resources for [The Complete Java Development Bootcamp](https://www.udemy.com/course/the-complete-java-development-bootcamp/?referralCode=F009B320F76ADA844248)
