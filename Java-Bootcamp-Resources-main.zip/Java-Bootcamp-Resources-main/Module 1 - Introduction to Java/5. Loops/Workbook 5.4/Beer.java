public class Beer {
    public static void main(String[] args) {
       // See detailed instructions on Learn the Part.
    }

}
