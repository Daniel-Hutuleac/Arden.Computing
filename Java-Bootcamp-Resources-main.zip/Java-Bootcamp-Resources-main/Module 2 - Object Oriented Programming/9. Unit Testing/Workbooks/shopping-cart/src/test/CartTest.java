package src.test;

import src.main.models.Cart;

public class CartTest {

    Cart cart;
    
}
