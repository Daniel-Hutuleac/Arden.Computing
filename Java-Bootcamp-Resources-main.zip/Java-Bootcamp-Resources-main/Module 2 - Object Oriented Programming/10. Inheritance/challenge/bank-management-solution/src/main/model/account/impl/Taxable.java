package src.main.model.account.impl;

public interface Taxable {
    public void tax(double income);
}
