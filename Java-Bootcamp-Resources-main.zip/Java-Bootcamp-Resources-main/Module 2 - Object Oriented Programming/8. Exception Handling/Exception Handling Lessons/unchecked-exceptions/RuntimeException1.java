public class RuntimeException1 {
    public static void main(String[] args) {
        int[] array = new int[3];

    }
}
