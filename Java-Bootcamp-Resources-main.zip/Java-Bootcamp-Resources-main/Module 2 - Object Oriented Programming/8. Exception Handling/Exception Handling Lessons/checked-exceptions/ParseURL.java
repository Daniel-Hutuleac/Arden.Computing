public class ParseURL {
    public static void main(String[] args) {

    }

}
