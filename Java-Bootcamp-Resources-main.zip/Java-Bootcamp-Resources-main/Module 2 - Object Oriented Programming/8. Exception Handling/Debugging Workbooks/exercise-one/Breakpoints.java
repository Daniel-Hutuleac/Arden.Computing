public class Breakpoints {
    public static void main(String[] args) {
        int number = 5 % 1;
        long largeNumber = 50000000000L;
        double decimal = 5.3;
        boolean bool = 10 % 2 == 0;
        char character = 'd';
        char character1 = 'e';
        char character2 = 'b';
        char character3 = 'u';
        char character4 = 'g';
        char character5 = 'g';
        char character6 = 'i';
        char character7 = 'n';
        char character8 = 'g';
        String message = "Debugging";
    }
}
