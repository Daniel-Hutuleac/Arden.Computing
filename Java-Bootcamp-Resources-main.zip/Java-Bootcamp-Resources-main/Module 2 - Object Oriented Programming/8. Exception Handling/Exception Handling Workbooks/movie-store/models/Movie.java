package models;

public class Movie {
    
}
